package com.beyond.kkwoborrow.complain.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ComplainRequestDto {
    private Long userId;
}
