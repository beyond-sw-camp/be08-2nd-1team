package com.beyond.kkwoborrow.alarm.entity;

public enum  AlarmType {
    Rental, // 대여
    Return, // 반납
    Reservation // 예약
}
