package com.beyond.kkwoborrow.login;

public class sessionConst {
    public static final String LOGIN_MEMBER = "loginMember";
}
