package com.beyond.kkwoborrow;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KkwoborrowApplicationTests {

	@Test
	void contextLoads() {
	}

}
