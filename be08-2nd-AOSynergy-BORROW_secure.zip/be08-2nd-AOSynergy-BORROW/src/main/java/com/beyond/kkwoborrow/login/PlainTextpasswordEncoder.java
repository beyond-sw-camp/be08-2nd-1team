package com.beyond.kkwoborrow.login;

import org.springframework.security.crypto.password.PasswordEncoder;

public class PlainTextpasswordEncoder implements PasswordEncoder {

    @Override
    public String encode(CharSequence rawPassword) {
        return rawPassword.toString(); // 암호화하지 않고 평문 그대로 반환
    }

    @Override
    public boolean matches(CharSequence rawPassword, String encodedPassword) {
        return rawPassword.toString().equals(encodedPassword); // 평문 비교
    }
}
