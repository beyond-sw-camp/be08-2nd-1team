package com.beyond.kkwoborrow.security;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class CustomPasswordService {

    private final PasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    // 평문 비밀번호를 암호화하고, 저장된 평문 비밀번호를 암호화하여 비교
    public boolean matchPassword(String rawPassword, String storedPlainPassword) {
        // 입력된 평문 비밀번호를 BCrypt로 암호화
        String encodedInputPassword = passwordEncoder.encode(rawPassword);

        // 저장된 평문 비밀번호를 BCrypt로 암호화
        String encodedStoredPassword = passwordEncoder.encode(storedPlainPassword);

        // 두 암호화된 비밀번호 비교
        return encodedInputPassword.equals(encodedStoredPassword);
    }
}
