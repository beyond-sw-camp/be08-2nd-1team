package com.beyond.kkwoborrow;

import com.beyond.kkwoborrow.users.service.UserService;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class KkwoborrowApplication {

	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(KkwoborrowApplication.class, args);

		// UserService 빈을 가져와서 사용
		UserService userService = context.getBean(UserService.class);

		// 사용자 정보를 콘솔에 출력
		userService.findAllUsers();
	}

}
