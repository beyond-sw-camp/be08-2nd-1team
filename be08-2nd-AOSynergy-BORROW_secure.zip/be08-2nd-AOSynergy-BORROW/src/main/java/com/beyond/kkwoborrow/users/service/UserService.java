package com.beyond.kkwoborrow.users.service;

import com.beyond.kkwoborrow.users.dto.UserRequestDto;
import com.beyond.kkwoborrow.users.dto.UserResponseDto;

import java.util.List;

public interface UserService {
    UserResponseDto save(UserRequestDto newUser);

    UserResponseDto getUser(Long userId);

    void deleteUser(Long userId);

    UserResponseDto updateUser(Long userId, UserRequestDto updateUser);

    UserResponseDto findByUsername(String username);

    UserResponseDto findByUsername(String username, String password);

    List<UserResponseDto> findAllUsers();
}
