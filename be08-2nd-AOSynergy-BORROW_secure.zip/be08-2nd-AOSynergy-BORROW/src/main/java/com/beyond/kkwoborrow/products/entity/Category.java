package com.beyond.kkwoborrow.products.entity;

public enum Category {
    BABYPRODUCTS, //육아용품
    TRAVELGEAR, //여행 및 캠핑용품
    ELECTRONICS, //전자제품
    HOUSEWARES, //생활용품
    HOBBIES, //취미용품
    APPLIANCES, //생활가전
    SPORTS, //스포츠용품
    PETSUPPLIES, //반려동물용품
}
