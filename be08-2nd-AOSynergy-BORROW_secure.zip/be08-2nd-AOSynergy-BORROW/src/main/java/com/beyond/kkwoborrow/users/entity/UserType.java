package com.beyond.kkwoborrow.users.entity;

public enum UserType {
    USER, // 일반 회원
    ADMIN // 관리자
}
